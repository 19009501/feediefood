package com.example.aahaarapp;

import android.os.Bundle;
import android.app.Activity;

public class DefineBiogas extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_definebiogas);
    }
}
